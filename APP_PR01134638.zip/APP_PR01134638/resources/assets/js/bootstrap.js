try {
    window.$ = window.jQuery = require('jquery');
    //window.Popper = require('popper.js');

    //require('bootstrap-sass');
    require('bootstrap');
} catch (e) {}